
package roughnums;

import java.util.Scanner;
import java.util.Random;

public class RoughNums {
   public static void main(String[]args) {
      Scanner reader = new Scanner(System.in);
      Random rand = new Random();
      int rantInt = rand.nextInt(101);

      while(true) {
         System.out.println("Hello friend! Pick a number between 1 - 100: ");
         int pick = Integer.parseInt(reader.nextLine());

         if(pick > 100) {
            System.out.println("Oops, number too big! Please try again!\n");
         } else {
            System.out.println("Let's see if I can get the same number too!");
         }

      }

   }
}